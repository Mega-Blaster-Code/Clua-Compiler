local PRE_TOKENS, KEYWORDS

do
    local info = require("tokens")
    PRE_TOKENS, KEYWORDS = info[1], info[2]
end

local functions = {
	-- ========= stdio.h
	malloc = true,
	calloc = true,
	realloc = true,
	free = true,

	atoi  = true, -- string to int
	atol  = true, -- string to long
	atoll = true, -- string to long long
	atof  = true, -- string to float
	itoa = true   -- int to string. char* str = itoa(int value, char* str, int base);
}

return {functions}