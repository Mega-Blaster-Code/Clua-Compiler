# clua README

sintax of lua but with static types