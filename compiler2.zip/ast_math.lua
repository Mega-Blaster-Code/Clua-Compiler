local table = {
    kind = "__BINARY_EXPRESSION",
    left = {
        kind = "__BINARY_EXPRESSION",
        left = {
            kind = "__LITERAL",
            value = 1
        },
        op = "+",
        right = {
            kind = "__LITERAL",
            value = 2
        }
    },
    op = "*",
    right = {
        kind = "__LITERAL",
        value = 2
    }
}

local function math(op, v1, v2)
    if op == "+" then
        return v1 + v2
    end
    if op == "*" then
        return v1 * v2
    end
    if op == "-" then
        return v1 - v2
    end
    if op == "/" then
        return v1 / v2
    end
end

local function count(tbl)
    print(tbl.kind)
    if tbl.kind == "__BINARY_EXPRESSION" then
        local op = tbl.op
        local result1 = count(tbl.left)
        local result2 = count(tbl.right)
        return math(op, result1, result2)
    end

    if tbl.kind == "__LITERAL" then
        return tonumber(tbl.value)
    end

    if tbl.op then
        return -tonumber(tbl.expr.value)
    end
end

print(count(table))
