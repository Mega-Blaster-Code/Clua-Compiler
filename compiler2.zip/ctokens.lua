local module = {}


local tokens = {
	-- ========= GENERIC
	__SEMICOLON = ";",
	__STRING = "STRING",
	__CHAR_LITERAL = "CHAR_LITERAL",
	__NAME = "NAME",
	__EQUAL_ASSIGNING = "=",
	__OPEN_PARENTHESES = "(",
	__CLOSE_PARENTHESES = ")",
	__OPEN_BRACKETS = "[",
	__CLOSE_BRACKETS = "]",
	__OPEN_BRACES = "{",
	__CLOSE_BRACES = "}",
	__COMMA = ",",
	__DOT = ".",
	__COLON = ":",
	__NEW_LINE = "\n",
	__AMPERSAND = "&",

	
	__LINE_COMMENT = "LINE_COMMENT",

	-- ========= KEY WORDS
	__IF = "if",
	__ELSE = "else",
	__ELSEIF = "else if",
	__THEN = "then",
	__FOR = "for",
	__DO = "{",
	__WHILE = "while",
	__BREAK = "break",
	__FALSE = "false",
	__TRUE = "true",
	__NIL = "NULL",
	__END = "}",
	__FUNCTION = "",
	__RETURN = "return",

	-- ========= MATH

	__MINUS = "-",
	__PLUS = "+",
	__ASTERISK = "*",
	__DIVIDE = "/",
	__MODULE = "%",

	-- ========= COMPARISON
	__EQUAL_COMPARISON = "==",
	__GREATER_OR_EQUAL = ">=",
	__GREATER = ">",
	__LOWER_OR_EQUAL = "<=",
	__LOWER = "<",
	__DIFFERENT = "!=",
	__OR = "||",
	__AND = "&&",
	__NOT = "!",

	-- ========= NUMBER (int's can be only (int, char, long, long or short). float's can only be (float and double)) 

	__NUMBER_INT = "NUMBER_INT",
	__NUMBER_FLOAT = "NUMBER_FLOAT",

	-- ========= TYPES
	__INT = "int",
	__CHAR = "char",
	__FLOAT = "float",
	__DOUBLE = "double",
	__LONG = "long",
	__SHORT = "short",
	__VOID = "void",
	__BOOL = "bool",
	__STRUCT = "struct",
	__TYPEDEF = "typedef",
	__SIZE_T = "size_t",

	-- ========= QUALIFIERS
	__SIGNED = "signed",
	__UNSIGNED = "unsigned",
	__CONST = "const",
	__VOLATILE = "volatile",
}

return tokens