--[[
table {
	<headers size>
	<I headers>
	<K headers>
	<data>
}

headers size = {
	<I size> -- u64
	<K size> -- u64
}

I header = {
	<type> -- u8
	<index> -- u64
	<pointer> (optional) -- u64
	<size> (optional) -- u64
}

K header = {
	<type> -- u8
	<key_size> -- u64
	<key> -- unknow (raw)
	<pointer> (optional) -- u64
	<size> (optional) -- u64
}

]] local _M = {}

local file2io = require("file2io")
local inspect = require("inspect")
local color8 = require("color8")
local bin = require("bin")

-- color8.fcolor(50, 50, 50)

local result_path = "result.tbl"

local TYPES = {
    INT = "\0",
    FLOAT = "\1",
    CHAR = "\2",
    STRING = "\3",
    TABLE = "\4",
    BOOLEAN_TRUE = "\5",
    BOOLEAN_FALSE = "\6",
    EMPTY_STRING = "\7",
    EMPTY_TABLE = "\8"
}

local HAS_PAYLOAD = {
    [TYPES.INT] = true,
    [TYPES.FLOAT] = true,
    [TYPES.CHAR] = true,
    [TYPES.STRING] = true,
    [TYPES.TABLE] = true
}

local HAS_SIZE = {
    [TYPES.STRING] = true,
    [TYPES.TABLE] = true
}

local CONST_DATA_SIZE = {
    [TYPES.INT] = 8,
    [TYPES.FLOAT] = 8,
    [TYPES.CHAR] = 1
}

local function getTableSize(tbl)
    local i = 0
    for k, v in pairs(tbl) do
        i = i + 1
    end
    return i
end

local my_tbl = {1}

local function createDataTable(data, index)
    local data_type = type(data)

    local result = {
        type = TYPES.INT,
        index = index
    }

    if type(index) == "string" then
        result.index = nil
        result.key = index
        result.key_size = #index
    end

    if data_type == "number" then
        local num_type = math.type(data)

        if num_type == "integer" then
            result.type = TYPES.INT
            result.raw = bin.int_to_u64(data)
        elseif num_type == "float" then
            result.type = TYPES.FLOAT
            result.raw = bin.float_to_u64(data)
        end

        return result
    end

    if data_type == "boolean" then
        result.type = (data and TYPES.BOOLEAN_TRUE) or TYPES.BOOLEAN_FALSE
        return result
    end

    if data_type == "string" then
        if #data == 0 then
            result.type = TYPES.EMPTY_STRING
            return result
        end

        if #data == 1 then
            result.type = TYPES.CHAR
            result.raw = data
            return result
        end

        result.type = TYPES.STRING
        result.raw = data
        result.size = #data
        return result
    end

    if data_type == "table" then
        local tbl_size = getTableSize(data)
        if tbl_size == 0 then
            result.type = TYPES.EMPTY_TABLE
            return result
        end

        result.type = TYPES.TABLE

		local carry_i = {}
		local carry_k = {}

		for k, value in pairs(data) do
			local raw = createDataTable(value, k)
			if type(k) == "number" then
				carry_i[k] = raw
			else
				carry_k[#carry_k + 1] = raw
			end
		end

		result.carry_i = carry_i
		result.carry_k = carry_k

		return result
    end
end

local function getCarryISize(carry_i)
	if not carry_i then
		return 0, 0
	end
	local header_size = 0
	local data_size = 0

	for i, value in ipairs(carry_i) do
		header_size = header_size + 1 -- type
		header_size = header_size + 8 -- index

		if HAS_PAYLOAD[value.type] then
			header_size = header_size + 8 -- pointer
			data_size = data_size + #value.raw
		end

		if HAS_SIZE[value.type] then
			header_size = header_size + 8 -- size
		end
	end
	return header_size, data_size
end

local function getCarryKSize(carry_k)
	if not carry_k then
		return 0, 0
	end

	local header_size = 0
	local data_size = 0

	for i, value in ipairs(carry_k) do
		header_size = header_size + 1 -- type
		header_size = header_size + 8 -- key_size
		header_size = header_size + #value.key -- key

		if HAS_PAYLOAD[value.type] then
			header_size = header_size + 8 -- pointer
			data_size = data_size + #value.raw
		end

		if HAS_SIZE[value.type] then
			header_size = header_size + 8 -- size
		end
	end
	return header_size, data_size
end

local raw_table = {}
raw_table.__index = raw_table

local function newContents()
	local self = setmetatable({}, raw_table)

	self.pointers = {}

	self.raw_header = {}
	self.raw_data = {}

	return self
end

function raw_table:newPointer(raw_data, index)
	local location = #table.concat(self.raw_data) + 1
	self.pointers[index] = location
	self:pushBackData(raw_data)
	return location
end

function raw_table:pushBackHeader(byte)
	self.raw_header[#self.raw_header + 1] = byte
end

function raw_table:pushBackData(byte)
	self.raw_data[#self.raw_data + 1] = byte
end

function raw_table:start(data_table)
	if not data_table.carry_i or not data_table.carry_k then
		self:pushBackHeader(bin.int_to_u64(0))
		self:pushBackHeader(bin.int_to_u64(0))
		self:pushBackHeader(bin.int_to_u64(0))
		self:pushBackHeader(bin.int_to_u64(0))
		return
	end
	local carry_i_header_size, carry_i_data_size = getCarryISize(data_table.carry_i)
	local carry_k_header_size, carry_k_data_size = getCarryKSize(data_table.carry_k)
	self:pushBackHeader(bin.int_to_u64(carry_i_header_size))
	self:pushBackHeader(bin.int_to_u64(carry_i_data_size))
	self:pushBackHeader(bin.int_to_u64(carry_k_header_size))
	self:pushBackHeader(bin.int_to_u64(carry_k_data_size))

	for i, value in ipairs(data_table.carry_i) do

		local pointer

		if HAS_PAYLOAD[value.type] then
			pointer = self:newPointer(value.raw, value.index or value.key)
		end

		self:pushBackHeader(value.type)
		self:pushBackHeader(bin.int_to_u64(value.index))

		if pointer then
			self:pushBackHeader(bin.int_to_u64(pointer))
		end

		if HAS_SIZE[value.type] then
			self:pushBackHeader(bin.int_to_u64(value.size))
		end

	end
end

function raw_table:getRawHeader()
	return table.concat(self.raw_header)
end
function raw_table:getRawData()
	return table.concat(self.raw_data)
end

local data_table = createDataTable({}, 1)

print(inspect(data_table))

local raw_contents_handler = newContents()
raw_contents_handler:start(data_table)

print(inspect(raw_contents_handler:getRawHeader()))
print(inspect(raw_contents_handler:getRawData()))
print(inspect(raw_contents_handler.pointers))

return _M
